# hello.py
# Written by Dave Musicant
# This program produces a traditional programmer's greeting.

print "Welcome to Intro CS, Adam!"